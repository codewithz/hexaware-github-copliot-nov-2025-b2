const HomePage = () => {
    return (<div><h1>Welcome to the Demo application.</h1></div>);
}

export default HomePage;
