# No Readme

## Introduction

This application does something. - no idea what. 

It can also be deployed - no idea how.

It might be good if we can monitor it - no idea how either.


## The Challenge

Can you create a readme file for this application? It should be a good readme file as you would expect for any properly maintained application.

